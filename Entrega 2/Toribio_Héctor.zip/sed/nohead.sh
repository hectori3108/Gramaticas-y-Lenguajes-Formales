sed '1d' <../data/situacion-epidemiologica-coronavirus-en-castilla-y-leon.csv >../data/nohead.txt

