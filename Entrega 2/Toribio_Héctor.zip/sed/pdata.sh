sed -e '/Valladolid/{
	s/.*Valladolid;//g
	s/;[0-9]*;[0-9]*\.[0-9]*\,.*$//
	w ../data/Valladolid.dat
	}' -e '/León/{
        s/.*León;//g
        s/;[0-9]*;[0-9]*\.[0-9]*\,.*$//
        w ../data/León.dat
        }' -e '/Palencia/{
        s/.*Palencia;//g
        s/;[0-9]*;[0-9]*\.[0-9]*\,.*$//
        w ../data/Palencia.dat
        }' -e '/Segovia/{
        s/.*Segovia;//g
        s/;[0-9]*;[0-9]*\.[0-9]*\,.*$//
        w ../data/Segovia.dat
        }' -e '/Zamora/{
        s/.*Zamora;//g
        s/;[0-9]*;[0-9]*\.[0-9]*\,.*$//
        w ../data/Zamora.dat
        }' -e '/Ávila/{
        s/.*Ávila;//g
        s/;[0-9]*;[0-9]*\.[0-9]*\,.*$//
        w ../data/Ávila.dat
        }' -e '/Salamanca/{
        s/.*Salamanca;//g
        s/;[0-9]*;[0-9]*\.[0-9]*\,.*$//
        w ../data/Salamanca.dat
        }' -e '/Soria/{
        s/.*Soria;//g
        s/;[0-9]*;[0-9]*\.[0-9]*\,.*$//
        w ../data/Soria.dat
        }' -e '/Burgos/{
        s/.*Burgos;//g
        s/;[0-9]*;[0-9]*\.[0-9]*\,.*$//
        w ../data/Burgos.dat
        }' ../data/situacion-epidemiologica-coronavirus-en-castilla-y-leon.csv

sed -i "1iCasos_Confirmados;Nuevos_Positivos;Altas;Fallecimientos" ../data/*.dat
