sed -n '/Valladolid/{
s/;[[:alpha:]][[:alpha:]]*;/-/
s/;[[:digit:]]*;[[:digit:]]*$//
w ../data/listadoval.csv
}' ../data/poblacion_municipios_ine_2019.csv
sed -i "1i\CodProvincia-CodMunicipio;NombreMunicipio;Poblacion" ../data/listadoval.csv
